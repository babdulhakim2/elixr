0.1
---
-  Defined AttrDict and extension hook for the import mechanism


0.0
---
-  Initial version