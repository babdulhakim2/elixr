Elixr
=====
A collection of general purpose utility functions and classes that can be used
within scripts, web and desktop(?) applications.
